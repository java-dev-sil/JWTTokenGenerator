package com.demo.JWTTokenGenerator;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JWTController {

	@Autowired
	JWTManager jWTManager;

	@GetMapping("/create")
	public String index() {

		 
		KeyPairGenerator keyPairGenerator = null;
		try {
			keyPairGenerator = KeyPairGenerator.getInstance("RSA");
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		keyPairGenerator.initialize(2048);
		KeyPair keyPair = keyPairGenerator.generateKeyPair();
		PrivateKey privateKey = keyPair.getPrivate();
		PublicKey publicKey = keyPair.getPublic();
		jWTManager = new JWTManager("RS256", privateKey, publicKey);
		return jWTManager.createToken1(privateKey, publicKey);
		
	}
	
//	@GetMapping("/createToken")
//	public String createToken() {
//	
//		
//		Date createdDate = new Date();
//		Date expirationDate = new Date(createdDate.getTime() + 1000);
//		KeyPairGenerator keyPairGenerator = null;
//		try {
//			keyPairGenerator = KeyPairGenerator.getInstance("RSA");
//		} catch (NoSuchAlgorithmException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		keyPairGenerator.initialize(2048);
//		KeyPair keyPair = keyPairGenerator.generateKeyPair();
//		PrivateKey privateKey = keyPair.getPrivate();
//		PublicKey publicKey = keyPair.getPublic();
//		jWTManager = new JWTManager("RS256", privateKey, publicKey);
//		Map<String, Object> claims = new HashMap<>();
//		
//		
//		claims.put(name, )
//		return jWTManager.createJWTToken("u1", claims, expirationDate);
//	
//	
//	}
//	}

}
