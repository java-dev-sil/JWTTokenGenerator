package com.demo.JWTTokenGenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtTokenGeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtTokenGeneratorApplication.class, args);
	}

}
