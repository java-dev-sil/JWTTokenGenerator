package com.demo.JWTTokenGenerator;

import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.xml.bind.DatatypeConverter;

import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JWTManager {

	private String env;

	private SignatureAlgorithm algorithm;

	private Key privateKey;
	private Key publicKey;
	private String base64Security;

	public JWTManager() {

	}

	public JWTManager(String algorithm, Key secretKey) {
		this(algorithm, secretKey, secretKey);
	}

	public JWTManager(String algorithm, @Nullable Key privateKey, @Nullable Key publicKey) {
		this.algorithm = SignatureAlgorithm.forName(algorithm);
		this.privateKey = privateKey;
		this.publicKey = publicKey;

	}

	public SignatureAlgorithm getAlgorithm() {
		return algorithm;
	}

	public JWTManager setAlgorithm(SignatureAlgorithm algorithm) {
		this.algorithm = algorithm;
		return this;
	}

	public Key getPrivateKey() {
		return privateKey;
	}

	public JWTManager setPrivateKey(Key privateKey) {
		this.privateKey = privateKey;
		return this;
	}

	public Key getPublicKey() {
		return publicKey;
	}

	public JWTManager setPublicKey(Key publicKey) {
		this.publicKey = publicKey;
		return this;
	}

	public String createJWTToken(String userId, long expiration) {
		return createJWTToken(userId, Collections.emptyMap(), expiration);
	}

	public String createJWTToken(String userId, Map<String, Object> claims, long expiration) {
		long currentTime = System.currentTimeMillis();

		JwtBuilder jwtBuilder = Jwts.builder();
		if (claims != null && !claims.isEmpty()) {
			jwtBuilder.setClaims(claims);
		}
		jwtBuilder.setSubject(userId).setAudience("OpenCGA users").setIssuedAt(new Date(currentTime))
				.signWith(algorithm, privateKey);

		// Set the expiration in number of seconds only if 'expiration' is
		// greater than 0
		if (expiration > 0) {
			jwtBuilder.setExpiration(new Date(currentTime + expiration * 1000L));
		}

		return jwtBuilder.compact();
	}

	public Claims parseToken(String token) {
		return parseToken(token, this.base64Security);
	}

	private Claims parseToken(String token, String base64Security) {
		try {
			Claims claims = Jwts.parser().setSigningKey(DatatypeConverter.parseBase64Binary(base64Security))
					.parseClaimsJws(token).getBody();
			if (claims == null) {
				return null;
			}
			if (this.env.equals(claims.get("env", String.class))) {
				return claims;
			}
			return null;
		} catch (Exception e) {
			return null;
		}
	}

	// public String createToken() {
	//
	// String clientSecret = "${clientSecret}"; // Or load from configuration
	// SecretKey sharedSecret =
	// Keys.hmacShaKeyFor(clientSecret.getBytes(StandardCharsets.UTF_8));
	// Instant now = Instant.now();
	//
	// String jwt =
	// Jwts.builder().setAudience("https://${yourOktaDomain}/oauth2/default/v1/token")
	// .setIssuedAt(Date.from(now)).setExpiration(Date.from(now.plus(5L,
	// ChronoUnit.MINUTES)))
	// // .setIssuer(clientId)
	// // .setSubject(clientId)
	// .setId(UUID.randomUUID().toString()).signWith(sharedSecret).compact();
	// }

	//("RS256", privateKey, publicKey
	public String createToken1( PrivateKey privateKey, PublicKey publicKey) {

		// PrivateKey privateKey = ;
		// Instant now = Instant.now();

//		Map<String, Object> rsaKeys = null;
//		try {
//			rsaKeys = getRSAKeys();
//		} catch (Exception e) {
//
//			e.printStackTrace();
//		}
//		privateKey = (PrivateKey) rsaKeys.get("MIIG4gIBAAKCAYEAx1TXRPqXHCgSDoA++LUR3mo5f6ZkGvdDMaBObNW+9LqRAwikt9AzCKWtpnELCoPdPLsGNr88UgevGF6/5EO34+UAjzijmoZJtUi88HURgjpHshLaJxbPBL9jb0i5Dy3QHX/TArhILco+gyZEHl2yM9eeKoq23LKjz8/3ojDbL4iY3+106cmmpXFKQZ10c21n+EI1YnzD5TyLlkl85bY2Ow85niZ0kmjRHuwGLLTgiNV+K+NX6U+LICfvFhzVEqqx+B6Py8Ylo5uQLWA0c/ooVSffnHVFdGzxCv/TeMeWMTx6mo4L0iKiL5KDh98E5KuEGbi5N0Xflkp2XTznUAq9I6PKAvA/Pdg2XTQJcxOm1Mazeub3ae/j66Z30Sy1pMFIApC00JuG+5g8f7j5imC+paD5cgWdheVVSZjEyTcw7BvuxCC3+9qAyz3Ko5yzlpwDKNzRY4Qitn240edOhwuK45Lo3ZLwIdUDI9GsTfNcikpyp6WQBdYhgn1DdVXgX86JAgMBAAECggGAW9dnaEzdmweLaksEuKsVFJl07K/Jp/MNbqwh9lt1pGThs7gjzN2M5gsQO4QSRkIDiZvSfR8Xt+P6dQwS9iWNcN9upo6+MtB03aYqB9CoxIv9xLqS8Te9Ir7cHcYwHiJJpY3jt3kZKJ/qtZrIAAXDucc7BPbs0jss5u83de90zi3t4h8SozVaJxhP0nOt2BEsumInHr3FtLV0y0YI2f5edk/JiGjHhT3uPIUbQzYDzogvniEdvE3+GE7OBi46rmMe0zdkUxEtxXToE/fyo44+Urz9x0EB7yf/3NSiZY6uDmiJ7oTb8Nn20z9KoPMDTowPvW0Q6GD3iPDhOSTSo421Orhp/F2wNfoz1lkBttzVE8MfNj/H+xOP5NHYqjLb1dQCRbS6GiqoSec6caPiCjxVVaBPnRMXaCr41I7aPxwcXgpSFJl6khf0Bp8A0DX39D/OtXRI2KCpSp9ZFr28XxUR9W1yBw/Fqf5UzlVD7WbR+ydIBUKW3GCSYKnKVBlT68ZBAoHBAP7uGovagYn12YQGZgJvHHuWFZttJyY4t1vOMNZcnOF8xdI1NnDUo5Ji9+vnYrCQsh0Rmpm0uFUnBm4jqTrVDA+Fc3CUnEpj\r\nXBzvs1JY/eQaaBs8XL2ViSrZezEM/C+j9wOHjLaFgsDCY16ZDkgYwRG9W3fIERH1aOCPu2fTPBiUzF4E3ujxCY8i0eFkOsoTNbYbsySJx8VC9LqSvJb0YZO8cmY3Lwjrf3TzDSuhwUwVSboZQ/8gVM7I4Fzbpai71QKBwQDIKwCJ1dzP7y/030LVPH2dldqnEvXHjs/fYNjXPkgLocsJZmlJ7F2F1iNUGCcf3WL7J2NXqLBX9SEbGUc8X/kag48P5vDzb51f7vIw4irrPtX+UHKiFODE7Fe2TmdZ6yj3PpptiVRke6x+f3wuDLdlygDRjqlaHDQr7dDMiBxZY4amtuZNl4RWOcS19HGF5e7f5Bh5KGQjco2lIB23G0GA8nHQ53bzgeyRCymbbagc3JbdhQFCbwCcRSo+U28iJeUCgcAF46ZFWNTpRP6zaBpvL/XufPce0hS3c1P5EPhb22Pcaa+APa52SNNGjHbBwmSrQ4x503BI4L3paa9iV/yO2WEf8qtKDITXyxfTq03vNxMWc+23w1s5Hf0/Oir4ZR5mU1lfgYAkr0zn+xWkl9CWpcvABynXyI1sZsj3dxqTOXQH9VgLS/2CUB8yaVGD7XbWOD9jZ5xp2az9x6AztzQYIKkoapASAHBbumUFZKAHRANdKJi9bdv+RtbuuAFG4+Qd08kCgcBxHKu/OBUBg55L9+Xibb5mUIowo2w0CqW5Cxc9+rnnqNP9SdvxpBntSWbJXKSvQwFt/4IJxQ9xhNniYFR675jqvLEZQV2jks0Rqws9SHEMYoO2pGtC4B1r6kpegMuyakrJ/JxzjYkdBy4ghZX8x77TTGVOBhn5C7sHn+m/yqKKeM1cZDqcWiS0PQzF7Y5BJf/okRKrVIHR7ifQyedA06weW+KpNENps1+lTvOCG2NGe/jc0Q43Jlbn98W5VpiUaWkCgcBFoYTKjsLNVWMy7BFbj2sINZiqxnCHZ/nzLA1hL5QBH1OWzhVs05MEYPoqMKTp9B56ZsyBfoW9ny5dQRNuTbm1wAfRgV/Vx8YU7CuwMqCopefiW9maL27QIETfcNtOPtv5HqBSPCBYELjIjo4XZhVmSiXsHDfuXFGZ0I0eFVKfy0vbN6sf3yhJ0S+bMWaweM8bwA4L4rGZ3fAs\r\n8KUMjT/6vwX7YsAUO3+tRnfYq3fgezyeXE0tw+KA7txycEWMKIo=");
//		privateKey = (PrivateKey) rsaKeys.get("private");
		Date createdDate = new Date();
		Date expirationDate = new Date(createdDate.getTime() + 1000);
		return Jwts.builder().setAudience("https://mysite/oauth2/default/v1/token").setIssuedAt(createdDate)
				.setExpiration(expirationDate)
				// .setIssuer(clientId)
				// .setSubject(clientId)
				.setId(UUID.randomUUID().toString()).signWith(algorithm, privateKey).compact();
	}

	// Get RSA keys. Uses key size of 2048.
	private static Map<String, Object> getRSAKeys() throws Exception {
		KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
		keyPairGenerator.initialize(2048);
		KeyPair keyPair = keyPairGenerator.generateKeyPair();
		PrivateKey privateKey = keyPair.getPrivate();
		PublicKey publicKey = keyPair.getPublic();
		Map<String, Object> keys = new HashMap<String, Object>();
		keys.put("private", privateKey);
		keys.put("public", publicKey);
		System.out.println();
		return keys;
	}


	// public static PrivateKey loadPrivateKey(String privateKeyStr) throws
	// Exception {
	// try {/* w w w. j a va 2s. c om */
	// byte[] buffer = Base64.decode(privateKeyStr, Base64.DEFAULT);
	// PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(buffer);
	// KeyFactory keyFactory = KeyFactory.getInstance(RSA);
	// return (RSAPrivateKey) keyFactory.generatePrivate(keySpec);
	// } catch (NoSuchAlgorithmException e) {
	// throw new Exception("");
	// } catch (InvalidKeySpecException e) {
	// throw new Exception("?");
	// } catch (NullPointerException e) {
	// throw new Exception("?");
	// }
	// }
}
