//package com.demo.JWTTokenGenerator;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class JwtTokenGeneratorApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
